import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Insert {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con1 = null;
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		con1 = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe", "hr" , "hr");
		//db����
		//("jdbc:oracle:thin:@127.0.0.1:1521:xe","hr","hr");
	/*	System.out.println("�����ߴ�");*/

		String sql2 = 
				"insert into teltable5 "
			  + "values (?,?,?,?)";
		
		/*Statement st2 = con1.createStatement();*/
		
		PreparedStatement ps2 = con1.prepareStatement(sql2);
		
		Scanner sc1 = new Scanner(System.in);
		System.out.print("��� : ");
		int id = sc1.nextInt();
		
		System.out.print("�̸� : ");
		String name = sc1.next();
		
		System.out.print("��ȭ��ȣ : ");
		String tel = sc1.next();
		
		System.out.print("�Ի��� : ");
		String ipsail1 = sc1.next();
		
		ps2.setInt(1 , id);
		ps2.setString(2, name);
		ps2.setString(3, tel);
		ps2.setString(4, ipsail1);
		
		
//		ps2.setInt(1, 15000);;
		//1st ? �� �޿� 15000�� �־��
		
		/*ResultSet rs2 = st2.executeQuery(sql2);*/
		
		int rowcnt1 = ps2.executeUpdate();
		//�μ�Ʈ ����Ʈ ������Ʈ�� �� ������Ʈ��
		System.out.println("�ߵ�� ��~�� " + rowcnt1 + "�� insert �ߴٴ�");
		
//		ResultSet rs2 = ps2.executeQuery();
		
//		while(rs2.next())
//		{
//			String fname = rs2.getString("�̸�");
//				//alias Ȱ�� (���� : ��° , �÷���)
//			int salary = rs2.getInt("���");
//			System.out.println(rs2.getRow() + "\t" + fname + "\t" +salary);
//		}
		
		con1.close();
		System.out.println("���ӳ�");
	}

}
