package sawonpkg;

public class Sawon{

		private String irum;
		private String na2;
		
		public Sawon()
		{
			
		}

		public String getIrum() {
			return irum;
		}

		public void setIrum(String irum) {
			this.irum = irum;
		}

		public String getNa2() {
			return na2;
		}

		public void setNa2(String na2) {
			this.na2 = na2;
		}
		
}
