import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Search {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con1 = null;
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		con1 = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe", "hr" , "hr");
		//db����
		//("jdbc:oracle:thin:@127.0.0.1:1521:xe","hr","hr");
	/*	System.out.println("�����ߴ�");*/

		String sql2 = 
				"select id , name , tel , d "
			  + "from teltable5";
//			  + "where id = ?";
		
//		Statement st2 = con1.createStatement();
		
		PreparedStatement ps2 = con1.prepareStatement(sql2);
		
//		ps2.setInt(1, 2);
		//1st ? �� �޿� 15000�� �־��
		
//		ResultSet rs2 = st2.executeQuery(sql2);
		
		ResultSet rs2 = ps2.executeQuery();
		
		while(rs2.next())
		{
			int id1 = rs2.getInt("id");
			String fname = rs2.getString("name");
				//alias Ȱ�� (���� : ��° , �÷���)
			String tel1 = rs2.getString("tel");
			String date1 = rs2.getString("d");
			System.out.println(rs2.getRow() + "\t" + id1 + "\t" + fname + "\t" + tel1 + "\t" + date1);
		}
		
		con1.close();
		System.out.println("���ӳ�");
	}

}
