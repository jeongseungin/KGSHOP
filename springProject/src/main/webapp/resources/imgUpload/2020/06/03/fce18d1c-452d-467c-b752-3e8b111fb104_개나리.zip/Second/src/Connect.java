import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Connect {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con1 = null;
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		con1 = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe", "hr" , "hr");
		//db����
		//("jdbc:oracle:thin:@127.0.0.1:1521:xe","hr","hr");
	/*	System.out.println("�����ߴ�");*/

		String sql2 = 
				"select * from employees "
			  + "where upper(first_name) like 'S%'";
		
		Statement st2 = con1.createStatement();
		
		ResultSet rs2 = st2.executeQuery(sql2);
		
		while(rs2.next())
		{
			int id=rs2.getInt("employee_id");
			String fname=rs2.getString("first_name");
			String h_date=rs2.getString("hire_date");
			String hire_date=h_date.substring(0,10);
			System.out.println(rs2.getRow() + "\t" + id + "\t" + fname + "\t\t" + hire_date);
		}
		
		con1.close();
		System.out.println("���ӳ�");
	}

}
