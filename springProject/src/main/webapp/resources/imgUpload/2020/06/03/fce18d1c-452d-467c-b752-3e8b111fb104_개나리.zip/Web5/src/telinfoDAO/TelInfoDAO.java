package telinfoDAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import telinfoDBConn.TelInfoDBConn;
import telinfoVO.TelInfoVO;

public class TelInfoDAO {
	private Connection con;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public TelInfoDAO() throws ClassNotFoundException, SQLException
	{
		con = new TelInfoDBConn().getConnection();
	}
	
	public void pstmtClose() throws SQLException
	{
		if(pstmt != null)
		{
			pstmt.close();
		}
	}
	
	public void getAllInfoClose() throws SQLException
	{
		if(rs != null)
		{
			rs.close();
		}
		if(pstmt != null)
		{
			pstmt.close();
		}
		if(con != null)
		{
			con.close();
		}
	}
	
	public ArrayList<TelInfoVO> getAllInfo() throws SQLException
	{
		ArrayList<TelInfoVO> tiarray = new ArrayList<TelInfoVO>();
		String sql = "select * from teltable5 order by id";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		while(rs.next())
		{
			int id = rs.getInt("id");
			String name = rs.getString("name");
			String tel = rs.getString("tel");
			Date d = rs.getDate("d");
			//import util�ƴ� sql��
			
			TelInfoVO tv = new TelInfoVO(id,name,tel,d);
			tiarray.add(tv);
		}
		return tiarray;
	}
	
	public TelInfoVO getInfo(String Name1) throws SQLException
	{
		TelInfoVO tv=null;
		String sql = "select * from teltable5 where name=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, Name1);
		rs = pstmt.executeQuery();
		if(rs.next())
		{
			int id=rs.getInt("id");
			String name=rs.getString("name");
			String tel=rs.getString("tel");
			Date d=rs.getDate("d");
			tv = new TelInfoVO(id,name,tel,d);
		}
		else
		{
			tv = null;
		}
		return tv;
	}
	
	public boolean update_all(int id1 , String name1 , String tel1 , String d , String sname) throws SQLException
	{
		String sql = "update TelTable5 set id=? , name=? , tel=? , d=TO_DATE(?,'YYYY-MM-DD') where name=?";
		
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1,  id1);
		pstmt.setString(2, name1);
		pstmt.setString(3, tel1);
		pstmt.setString(4, d);
		pstmt.setString(5, sname);
		
		pstmt.executeUpdate();
		
		return true;
	}
	
	public boolean update_nametel(String tel2,String name2)
	{
		String sql = "update TelTable5 set tel = ? where name=?";
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, tel2);
			pstmt.setString(2, name2);
			pstmt.executeUpdate();
		}
		catch(SQLException e)
		{
			System.out.println("update Exception");
			return false;
		}
		return true;
	}
	
	public boolean delete_nametel(String name3)
	{
		String sql = "delete from TelTable5 where name=?";
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, name3);
			pstmt.executeUpdate();
		}
		catch(SQLException e)
		{
			System.out.println("delete Exception");
			return false;
		}
		return true;
	}
	
	/*�ڹ��� sql�� Dateó���� �ٸ���
	- java.util.Date java.sql.Date
	
	1)to_date(?,'yyyy-MM-dd')
	2)SimpleDateFormat
		.parse .format
	3)java , substring*/
	
	public boolean insert_nametel(int id1 , String name4 , String tel3 , Date sdate)
	{
		String sql = "insert into TelTable5 "
				   + "values(?,?,?,?)";
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, id1);
			pstmt.setString(2, name4);
			pstmt.setString(3, tel3);
			/*pstmt.setDate(4, d2);*/
//			int year = Integer.parseInt(sdate.substring(0,4))-1900;
//			int month= Integer.parseInt(sdate.substring(4,6))-1;
//			int day  = Integer.parseInt(sdate.substring(6,8));
//			Date d = new Date(year,month,day);
			pstmt.setDate(4, sdate);

			pstmt.executeUpdate();
		}
		catch(SQLException e)
		{
			System.out.println("insert Exception");
			return false;
		}
		return true;
	}
}
